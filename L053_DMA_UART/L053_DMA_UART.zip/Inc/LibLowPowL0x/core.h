/*
 * core.h
 *
 *  Created on: Jan 22, 2022
 *      Author: tomoy
 */

#ifndef LIBLOWPOWL0X_CORE_H_
#define LIBLOWPOWL0X_CORE_H_


#include <stdint.h>
#include <stdbool.h>
#include "stm32l0xx.h"




#endif /* LIBLOWPOWL0X_CORE_H_ */
